<?php
	include"koneksi.php";
	
	
	
	session_start();
		$_SESSION['id_admin'] = "";
		$_SESSION['username'] = "";
		$_SESSION['level'] = "";
		$_SESSION['status'] = "";
		session_destroy();
		
		echo"<script type='text/javascript'>
							   //<![CDATA[
									alert('Logout Berhasil ..');
									window.location='../index.php';				   
							   //]]>
							 </script>";  
	

?>