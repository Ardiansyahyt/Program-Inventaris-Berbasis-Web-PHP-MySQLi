<?php
		include"../koneksi.php";

		$id = $_GET['hapus'];
		$sql1 = "delete from tabel_inventaris where id_inventaris ='$id'";
		$oke = mysqli_query($konek,$sql1);

		echo"<script type='text/javascript'>
							   //<![CDATA[
									alert('Data Berhasil Hapus');
									window.location='../data_inventaris.php';				   
							   //]]>
							 </script>";

?>