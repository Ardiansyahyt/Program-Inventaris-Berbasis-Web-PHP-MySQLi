<?php


		if (isset($_POST['login'])){

		include ('../koneksi.php');
		$user=$_POST['username'];
		$pass=$_POST['password'];

		$masuk="select count(username) from tabel_manager where username='$user' and password=md5('$pass')";
		$query=mysqli_query($konek,$masuk);
		$chek=mysqli_fetch_row($query);

		if ( $chek[0]>0 )
		{
			echo"<script type='text/javascript'>
							   //<![CDATA[
									alert('Selamat datang $user');
									window.location='../inventaris.php';				   
							   //]]>
							 </script>";

		}else
		{
			echo"<script type='text/javascript'>
							   //<![CDATA[
									alert('Gagal $user');
									window.location='proses/proses_manager.php';				   
							   //]]>
							 </script>";
		}
	}

?>