<?php

	include"../koneksi.php";
	
	if ( isset($_POST['tbl']) )
	{
		$bkl =	$_POST['bekal'];
		$prltn	 =  $_POST['peralatan'];
		$msn =  $_POST['mesin'];
		$prb	 =  $_POST['perabot'];
		$psw	 =  $_POST['pesawat'];
		
		$sql = "insert into tabel_inventaris (bekal_kantor,peralatan_kantor,mesin_kantor,perabot_kantor,pesawat_kantor)
				VALUES ('$bkl','$prltn','$msn','$prb','$psw')";
		mysqli_query($konek,$sql);
		
		echo"<script type='text/javascript'>
							   //<![CDATA[
									alert('Data Berhasil Disimpan');
									window.location='../data_inventaris.php';				   
							   //]]>
							 </script>";
		
	}else
	{
		echo"jangan nerobos aja donk";
	}

?>