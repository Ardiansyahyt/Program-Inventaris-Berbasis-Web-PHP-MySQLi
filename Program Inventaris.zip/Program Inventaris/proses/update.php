			<?php

				include"../koneksi.php";

				if ( isset($_POST['update']) )
				{
					$id =  $_POST['id'];
					$bkl =	$_POST['bekal'];
					$prltn	 =  $_POST['peralatan'];
					$msn =  $_POST['mesin'];
					$prb	 =  $_POST['perabot'];
					$psw	 =  $_POST['pesawat'];

				  $edit  = "UPDATE tabel_inventaris SET bekal_kantor = '$bkl',
									peralatan_kantor = '$prltn',
									mesin_kantor = '$msn',
									perabot_kantor = '$prb',
									pesawat_kantor = '$psw' WHERE id_inventaris = '$id' ";
									
				  mysqli_query($konek,$edit);
				  echo"<script type='text/javascript'>
										   //<![CDATA[
												alert('Data Berhasil Di Update');
												window.location='../data_inventaris.php';				   
										   //]]>
										 </script>";
				}
				else
				{
					echo "jangan nerobozz...";
				}


			?>