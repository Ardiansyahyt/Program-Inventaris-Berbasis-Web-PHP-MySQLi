<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
	<title>SISTEM INVENTARIS</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css"/>
	<link rel="stylesheet" href="assets/css/sosmed.css"/>
	<link rel="stylesheet" href="master.css" />
</head>
<body>
	
	<div class="container">
		<div class="row" style="margin-top:50px;">
			<div class="col-md-12">
				<nav class="navbar navbar-default" role="navigation">
				  <div class="container-fluid">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
					  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					  </button>
					  <a class="navbar-brand" href="inventaris.php">HOME</a>
					</div>

					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					  <ul class="nav navbar-nav">
						<li ><a href="data_inventaris.php">DATA INVENTARIS</a></li>
						<li ><a href="tambah_data.php">TAMBAH DATA INVENTARIS</a></li>
					  <form style="margin-left:300px;" class="navbar-form navbar-right" role="search">
						<div class="form-group">
						  <input type="text" class="form-control" placeholder="Search">
						</div>
						<button type="submit" class="btn btn-primary">Submit</button>
					  </form>
					  <li ><a href="index.php">Log Out</a></li>
					</div><!-- /.navbar-collapse -->
				  </div><!-- /.container-fluid -->
				</nav>
			</div>
		</div>
		
		<div class="row">
			<div class="col-md-12">
				 <div class="page-header">
					<center><h1 style="color:#A5A5A5;font-style:italic;">SELAMAT DATANG </h1></center>
					<center><h2 style="color:#A5A5A5;font-style:italic;">DI APLIKASI INVENTARIS DATA</h2></center>
				  </div>
			</div>
		</div>
		
	</div>
	
</body>
</html>