<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
	<title>Sistem Inventaris</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css"/>
	<link rel="stylesheet" href="assets/css/sosmed.css"/>
	<link rel="stylesheet" href="master.css" />
	
	
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="col-md-4">
					
				</div>
				<div class="col-md-4"  id="custom-heading" style="margin-top:100px;">
					 <p style="font-size:25px;margin-left:55px;color:#fff;font-style:italic;">SISTEM INVENTARIS</p>
				</div>
				<div class="col-md-4">
					
				</div>
			</div>
		</div>
		
		<div class="row" style="margin-top:100px;">
			<div class="col-md-12">
				<div class="col-md-3">
					<div class="panel panel-primary">
					  <div class="panel-heading">
						<h3 class="panel-title">MANAGER</h3>
					  </div>
					  <div class="panel-body">
						<span style="margin-left:100px;" class="glyphicon glyphicon-user"></span>
					  </div>
				</div>
				<div class="panel panel-success" style="background:#55AAFF;margin-top:-21px;border-radius:8px;">
					  <div class="panel-body">
						<a style="text-decoration: none;margin-left:90px;font-size:13pt;color:#fff;" href="loginmanager.php" title="welcome">LOGIN</a>
					  </div>
				</div>
				</div>
				<div class="col-md-2">
					
				</div>
				<div class="col-md-2">
					<img src="img/1.jpg" width="100%" height="100" alt="1" />
				</div>
				<div class="col-md-2">
					
				</div>
				<div class="col-md-3">
					<div class="panel panel-primary">
					  <div class="panel-heading">
						<h3 class="panel-title">KEPSEK</h3>
					  </div>
					  <div class="panel-body">
						<span style="margin-left:100px;" class="glyphicon glyphicon-user"></span>
					  </div>
				</div>
				<div class="panel panel-success" style="background:#55AAFF;margin-top:-21px;border-radius:8px;">
					  <div class="panel-body">
						<a style="text-decoration: none;margin-left:90px;font-size:13pt;color:#fff;" href="loginkepsek.php" title="welcome">LOGIN</a>
					  </div>
				</div>
				</div>
				<div class="col-md-3">
					
				</div>
			</div>
		</div>
		
	</div>
	
</body>
</html>