<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
	<title>SISTEM INVENTARIS</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css"/>
	<link rel="stylesheet" href="assets/css/sosmed.css"/>
	<link rel="stylesheet" href="master.css" />
</head>
<body>
	
	<div class="container">
		<div class="row" style="margin-top:50px;">
			<div class="col-md-12">
				<nav class="navbar navbar-default" role="navigation">
				  <div class="container-fluid">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
					  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					  </button>
					  <a class="navbar-brand" href="inventaris.php">HOME</a>
					</div>

					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					  <ul class="nav navbar-nav">
						<li ><a href="data_inventaris.php">DATA INVENTARIS</a></li>
						<li ><a href="tambah_data.php">TAMBAH DATA INVENTARIS</a></li>
					  <form style="margin-left:380px;" class="navbar-form navbar-right" role="search">
						<div class="form-group">
						  <input type="text" class="form-control" placeholder="Search">
						</div>
						<button type="submit" class="btn btn-primary">Submit</button>
					  </form>
					</div><!-- /.navbar-collapse -->
				  </div><!-- /.container-fluid -->
				</nav>
			</div>
		</div>
		
		<div class="row">
			<div class="col-md-1">
				
			</div>
			<div class="col-md-10">
				<div class="jumbotron">
					 <div class="panel panel-default">
					  <div class="panel-heading"><b>INPUT DATA INVENTARIS</b></div>
					   <div class="panel-body">
					   
					   <?php

							include"koneksi.php";

							$id =$_GET['id'];
							$sql = "select * from tabel_inventaris where id_inventaris ='$id'";
							$query= mysqli_query ($konek,$sql);
							$data = mysqli_fetch_assoc ($query);

						?>
					   
						 <form class="form-horizontal" method="post" action="proses/update.php">
						   <table  class="table table-condensed">
						   <input type="hidden" name="id" value="<?php echo $data['id_inventaris'];?>" />
							 <b>Bekal Kantor :</b>
							 <input type="text" name="bekal" value="<?php echo $data['bekal_kantor'];?>" class="form-control" placeholder="Masukan Bekal Kantor"/> </br>
							 <b>Peralatan Kantor :</b>
							 <input type="text" name="peralatan" value="<?php echo $data['peralatan_kantor'];?>" class="form-control" placeholder="Masukan Peralatan Kantor"/> </br>
							 <b>Mesin Kantorr :</b>
							 <input type="text" name="mesin" value="<?php echo $data['mesin_kantor'];?>" class="form-control" placeholder="Masukan Mesin Kantor"/> </br>
							 <b>Perabot Kantor:</b>
							 <input type="text" name="perabot" value="<?php echo $data['perabot_kantor'];?>" class="form-control" placeholder="Masukan Perabot Kantor"/> </br>
							 <b>Pesawat Kantor:</b>
							 <input type="text" name="pesawat" value="<?php echo $data['pesawat_kantor'];?>" class="form-control" placeholder="Masukan Pesawat Kantor"/> </br>
							 <input type="submit" name="update" value="UPDATE" class="btn btn-info"> &nbsp; <input type="reset" value="RESET"class="btn btn-success"/>
						   </table>
						 </form>
					   </div>
					</div>
			</div>
			<div class="col-md-1">
				
			</div>
		</div>
		
	</div>
	
</body>
</html>