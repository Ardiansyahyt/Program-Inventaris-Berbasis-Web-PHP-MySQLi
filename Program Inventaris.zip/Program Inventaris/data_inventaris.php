<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
	<title>SISTEM INVENTARIS</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css"/>
	<link rel="stylesheet" href="assets/css/sosmed.css"/>
	<link rel="stylesheet" href="master.css" />
</head>
<body>
	
	<div class="container">
		<div class="row" style="margin-top:50px;">
			<div class="col-md-12">
				<nav class="navbar navbar-default" role="navigation">
				  <div class="container-fluid">
					<!-- Brand and toggle get grouped for better mobile display -->
					<div class="navbar-header">
					  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					  </button>
					  <a class="navbar-brand" href="inventaris.php">HOME</a>
					</div>

					<!-- Collect the nav links, forms, and other content for toggling -->
					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					  <ul class="nav navbar-nav">
						<li ><a href="data_inventaris.php">DATA INVENTARIS</a></li>
						<li ><a href="tambah_data.php">TAMBAH DATA INVENTARIS</a></li>
					  <form style="margin-left:380px;" class="navbar-form navbar-right" role="search">
						<div class="form-group">
						  <input type="text" class="form-control" placeholder="Search">
						</div>
						<button type="submit" class="btn btn-primary">Submit</button>
					  </form>
					</div><!-- /.navbar-collapse -->
				  </div><!-- /.container-fluid -->
				</nav>
			</div>
		</div>
		
		<div class="row">
		 <div class="container" style="margin-top: 0px"; >
		  <div class="page-header">
			<center><h1>DATA INVENTARIS KANTOR</h1></center>
		  </div>
		</div>
			<div class="col-md-1">
				
			</div>
			<div class="col-md-10"  id="custom-heading1">
				<table class="table table-hover">
						 <tr>
							<td><b>Bekal Kantor</b></td>
							<td><b>PeralatanKantor</b></td>
							<td><b>Mesin Kantor</b></td>
							<td><b>Perabot Kantor</b></td>
							<td><b>Pesawat Kantor</b></td>
							<td><b>Option</b></td>
						 </tr>

							<?php
	
								include"koneksi.php";								
								$no =0;
									
									$sql = "select * from tabel_inventaris order by id_inventaris desc ";
									$query = mysqli_query($konek,$sql);
									
									while ( $data = mysqli_fetch_assoc($query))
									
									{

								$no++;
							?>
							
							<tr>
								
							
							<td><?php echo $no?></td>
							<td><?php echo $data['bekal_kantor']?></td>
							<td><?php echo $data['peralatan_kantor']?></td>
							<td><?php echo $data['mesin_kantor']?></td>
							<td><?php echo $data['perabot_kantor']?></td>
							<td><?php echo $data['pesawat_kantor']?></td>
							<td><a href="edit_data.php?id=<?php echo $data['id_inventaris']?>" class="btn btn-primary"><i class="glyphicon glyphicon-pencil"></i> Edit</a> <a href="proses/hapus.php?hapus=<?php echo $data['id_inventaris']?>" class="btn btn-danger"><i class="glyphicon glyphicon-remove"></i> Delete</a></tr>
						  
							</tr>
							
							
							<?php
							
							}
							?>
						
				</table>
			</div>
			<div class="col-md-1">
				
			</div>
		</div>
		
	</div>
	
</body>
</html>