<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
	<title>Sistem Inventaris</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css"/>
	<link rel="stylesheet" href="assets/css/sosmed.css"/>
	<link rel="stylesheet" href="master.css" />
	
	
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="col-md-4">
					
				</div>
				
				<div class="col-md-4" style="margin-top:200px;" id="custom-heading">
				
				<p style="margin-left:95px;font-size:17px;color:#fff;">SISTEM INVENTARIS</p>
					<form role="form"  method="post" action="proses/proses_manager.php">
					  <div class="form-group">
						<label for="exampleInputEmail1" style="color:#fff;">Username</label>
						<input type="text" name="username" class="form-control" id="exampleInputEmail1" placeholder="Username">
					  </div>
					  <div class="form-group">
						<label for="exampleInputPassword1" style="color:#fff;">Password</label>
						<input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
					  </div>
					  <button type="submit"name="login"  class="btn btn-danger" style="margin-left:280px;">Login</button>
					</form>
				</div>
				
				<div class="col-md-4">
					
				</div>
				
			</div>
		</div>
	</div>
	
</body>
</html>