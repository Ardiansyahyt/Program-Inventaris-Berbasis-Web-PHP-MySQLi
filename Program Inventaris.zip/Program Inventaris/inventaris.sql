-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 27, 2017 at 06:40 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `inventaris`
--

-- --------------------------------------------------------

--
-- Table structure for table `tabel_inventaris`
--

CREATE TABLE IF NOT EXISTS `tabel_inventaris` (
  `id_inventaris` int(11) NOT NULL AUTO_INCREMENT,
  `bekal_kantor` varchar(50) NOT NULL,
  `peralatan_kantor` varchar(50) NOT NULL,
  `mesin_kantor` varchar(50) NOT NULL,
  `perabot_kantor` varchar(50) NOT NULL,
  `pesawat_kantor` varchar(50) NOT NULL,
  PRIMARY KEY (`id_inventaris`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tabel_inventaris`
--

INSERT INTO `tabel_inventaris` (`id_inventaris`, `bekal_kantor`, `peralatan_kantor`, `mesin_kantor`, `perabot_kantor`, `pesawat_kantor`) VALUES
(2, 'kertas', 'gunting', 'mesin tik', 'meja', 'interkom'),
(3, 'karbon', 'penggaris', 'mesin penomor', 'kursi', 'telepohone'),
(4, 'pita panjang kelapa', 'cutter', 'kalkulator', 'lemari', 'internet');

-- --------------------------------------------------------

--
-- Table structure for table `tabel_manager`
--

CREATE TABLE IF NOT EXISTS `tabel_manager` (
  `id_manager` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `password` varchar(40) NOT NULL,
  PRIMARY KEY (`id_manager`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tabel_manager`
--

INSERT INTO `tabel_manager` (`id_manager`, `username`, `password`) VALUES
(1, 'manager', '1d0258c2440a8d19e716292b231e3190');

-- --------------------------------------------------------

--
-- Table structure for table `table_kepsek`
--

CREATE TABLE IF NOT EXISTS `table_kepsek` (
  `id_kepsek` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `password` varchar(40) NOT NULL,
  PRIMARY KEY (`id_kepsek`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `table_kepsek`
--

INSERT INTO `table_kepsek` (`id_kepsek`, `username`, `password`) VALUES
(1, 'kepsek', '8561863b55faf85b9ad67c52b3b851ac');
